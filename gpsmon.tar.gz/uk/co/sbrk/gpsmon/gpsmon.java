package uk.co.sbrk.gpsmon;

import java.io.*;
import java.util.Enumeration;

import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import javax.microedition.location.*;

import javax.microedition.io.*;

import javax.microedition.rms.*;

public class gpsmon extends MIDlet implements CommandListener {
	// versions of various things
	String props;
	String url = "http://www.sbrk.co.uk/c/updloc";
	
	// title screen
	List tscreen;
	// display
	Display display;
	
	// gps stuff
	Criteria cr;
	LocationProvider lp;
	Coordinates c;
	QualifiedCoordinates qc;
	Location l;
	LandmarkStore ls;
	AddressInfo ai;
	String lstores[];
	Enumeration e;
	Enumeration ec;

	MovementTracker mt;

	// exit command
	private Command exitcmd = new Command("Exit", Command.EXIT, 1);

	// 
	// application
	public gpsmon() {
		props = " mlv: "+
			System.getProperty("microedition.location.version");

		display = Display.getDisplay(this);
		tscreen = new List("gpsmon", List.IMPLICIT);
		tscreen.append(props, null);
		tscreen.addCommand(exitcmd);
		tscreen.setCommandListener(this);

		// Initialise record store
		RecordStore rs = null;
		RecordEnumeration re = null;

		try {
			rs = RecordStore.openRecordStore("rs", true);
			re = rs.enumerateRecords((RecordFilter)null,
			                    (RecordComparator)null, false);
		} catch (RecordStoreException rse) {
			tscreen.append("rse", null);
		}
			

		// initialise gps
		cr = new Criteria();
		cr.setPreferredPowerConsumption(Criteria.POWER_USAGE_HIGH);
		//cr.setPreferredPowerConsumption(Criteria.NO_REQUIREMENT);
		//cr.setPreferredPowerConsumption(Criteria.POWER_USAGE_MEDIUM);
		//cr.setPreferredPowerConsumption(Criteria.POWER_USAGE_LOW);
		//cr.setAddressInfoRequired(true);
		//cr.setAltitudeRequired(true);
		//cr.setHorizontalAccuracy(500);
		//cr.setPreferredResponseTime(1000);
		//cr.setSpeedAndCourseRequired(true);
		//cr.setVerticalAccuracy(200);

		// get landmarkstore
		try {
			ls = LandmarkStore.getInstance(null);
			lstores = ls.listLandmarkStores();
			if (lstores != null) {
				tscreen.append("ls:"+lstores.length, null);
			}
			e = ls.getLandmarks();
			//tscreen.append("lsl:"+e.length(), null);
			if (e != null) {
				for (ec = e; ec.hasMoreElements() ;) {
					l = (Location)ec.nextElement();
					tscreen.append("e:"+l.getExtraInfo("text/plain"), null);
				}
			}
			//tscreen.append(lstores, null);
		} catch (IOException e) {
			tscreen.append("ioe", null);
		}

		// get initial coords
		try {
			lp = LocationProvider.getInstance(cr);

			// get current state
			tscreen.append("state "+lp.getState(), null);

			// Ignore Orientation

			// TODO LocationListener
			// TODO ProximityListener

			//l = lp.getLocation(5);
			l = LocationProvider.getLastKnownLocation();

			if (l != null) {
				qc  = l.getQualifiedCoordinates();

				ai = l.getAddressInfo();
				if (ai == null) {
					tscreen.append("noai", null);
				} else {
					tscreen.append("ai", null);
				}
			}
					HttpConnection con = null;
					try {
						con = (HttpConnection) Connector.open(url+"?start=1");
						con.setRequestMethod(HttpConnection.GET);
						tscreen.append(con.getResponseMessage(), null);
					} catch (Exception e) {
						tscreen.append("httpfail", null);
					} finally {
						try {
							if (con != null)
								con.close();
						} catch (IOException io) {
							tscreen.append(io.getMessage(), null);
						}
					}
			if (l !=null && l.isValid()) {
				// show position info
				tscreen.append("course "+l.getCourse(), null);
				tscreen.append("extra "+l.getExtraInfo("text/plain"), null);
				tscreen.append("meth "+l.getLocationMethod(), null);
				tscreen.append("speed "+l.getSpeed(), null);
				tscreen.append("tstamp "+l.getTimestamp(), null);
				qc = l.getQualifiedCoordinates();
				tscreen.append("qc la "+qc.getLatitude()+
					" ln "+qc.getLongitude()+
					" alt "+qc.getAltitude()+
					" ha "+qc.getHorizontalAccuracy()+
					" va "+qc.getVerticalAccuracy(), null);
					// notify http server
					//HttpConnection con = null;
					con = null;
					try {
						con = (HttpConnection) Connector.open(url+"?last=1&ln="+
							qc.getLongitude()+
							"&lt="+
							qc.getLatitude());
						con.setRequestMethod(HttpConnection.GET);
						tscreen.append(con.getResponseMessage(), null);
					} catch (Exception e) {
						tscreen.append("httpfail", null);
					} finally {
						try {
							if (con != null)
								con.close();
						} catch (IOException io) {
							tscreen.append(io.getMessage(), null);
						}
					}
			}
			mt = new MovementTracker(tscreen, (float)0.5);
		} catch (LocationException e) {
			tscreen.append("le", null);
		//} catch (InterruptedException e) {
		//	tscreen.append("ie", null);
		}


	}

	// start midlet
	protected void startApp() throws MIDletStateChangeException {
		display.setCurrent(tscreen);
	}

	// pause
	protected void pauseApp() {
		tscreen.append("paused", null);
	}

	// destroy
	protected void destroyApp(boolean unconditional)
		throws MIDletStateChangeException {

		tscreen.deleteAll();
		tscreen = null;
		display = null;
	}

	// process commands
	public void commandAction(Command c, Displayable d) {
		if (c == exitcmd) {
			try {
				this.destroyApp(true);
				notifyDestroyed();
			} catch (MIDletStateChangeException e) {
				tscreen.append("destroyfail", null);
			}

		} else {
			tscreen.append("othercmd", null);
		}
	}

}

// vim: se ic ai nows:

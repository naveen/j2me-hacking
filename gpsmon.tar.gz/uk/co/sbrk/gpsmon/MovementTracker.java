package uk.co.sbrk.gpsmon;

import java.io.*;
//import java.util.Enumeration;

import javax.microedition.lcdui.*;
//import javax.microedition.midlet.*;
import javax.microedition.location.*;

import javax.microedition.io.*;

class MovementTracker implements LocationListener {
	float movementDistance;
	LocationProvider provider;
	Location lastValidLocation;
	UpdateHandler handler;
	boolean done;
	List tscreen;
	String url = "http://www.sbrk.co.uk/c/updloc";

	public MovementTracker(List ts, float movementDistance) throws LocationException {
		this.movementDistance = movementDistance;
		tscreen = ts;
		done = false;
		handler = new UpdateHandler();
		new Thread(handler).start();
		provider = LocationProvider.getInstance(null);
		provider.setLocationListener(this, -1, -1, -1);
		//provider.setLocationListener(this, 5, 5, -1);
	}

	public void locationUpdated(LocationProvider provider, Location location) {
		handler.handleUpdate(location);
	}

	public void providerStateChanged(LocationProvider provider, int newState) {
	}

	class UpdateHandler implements Runnable {
		private Location updatedLocation = null;

		// The run method performs the actual processing of the location
		// updates

		public void run() {
			Location locationToBeHandled = null;

			while (!done) {
				synchronized(this) {
					if (updatedLocation == null) {
						try {
							wait();
						} catch (Exception e) {
							// Handle interruption
						}
					}
					locationToBeHandled = updatedLocation;
					updatedLocation = null;
				}

				//  The benefit of the MessageListener is here.
				//  This thread could via similar triggers be
				//  handling other kind of events as well in
				//  addition to just receiving the location updates.
				if  (locationToBeHandled != null)
					processUpdate(locationToBeHandled);
				updatedLocation = null;
			}
		}

		public synchronized void handleUpdate(Location update) {
			updatedLocation = update;
			notify();
		}

		private void processUpdate(Location update) {
			QualifiedCoordinates qc;
			if (update.isValid()) {
				// show position info
				tscreen.append("upd course "+update.getCourse(), null);
				tscreen.append("extra "+update.getExtraInfo("text/plain"), null);
				tscreen.append("meth "+update.getLocationMethod(), null);
				tscreen.append("speed "+update.getSpeed(), null);
				tscreen.append("tstamp "+update.getTimestamp(), null);
				qc = update.getQualifiedCoordinates();
				tscreen.append("qc la "+qc.getLatitude()+
					" ln "+qc.getLongitude()+
					" alt "+qc.getAltitude()+
					" ha "+qc.getHorizontalAccuracy()+
					" va "+qc.getVerticalAccuracy(), null);

				// notify http server
				HttpConnection con = null;
				try {
					con = (HttpConnection) Connector.open(url+"?upd=1&ln="+
						qc.getLongitude()+
						"&lt="+
						qc.getLatitude());
					con.setRequestMethod(HttpConnection.GET);
					tscreen.append(con.getResponseMessage(), null);
				} catch (Exception e) {
					tscreen.append("httpfail", null);
				} finally {
					try {
						if (con != null)
							con.close();
					} catch (IOException io) {
						tscreen.append(io.getMessage(), null);
					}
				}

			} else
				tscreen.append("invupd", null);
			if (update != null && update.isValid()) {
				if (lastValidLocation == null)
					lastValidLocation = update;
				if ( update.getQualifiedCoordinates().distance(
					lastValidLocation.getQualifiedCoordinates()) >
					movementDistance ) {
					// Alert user to movement...
					// Cache new position as we have moved a sufficient distance
					// from last one
					lastValidLocation = update;
				}
			}
		}
	}
}
// vim: se ic ai nows:

microEWT 0.92
Copyright (c) 2007 Elmar Sonnenschein / esoco GmbH
Documentation and support: http://www.esoco.net
Sourceforge project:       http://www.sourceforge.net/projects/microewt

-----------------------------------------------------------------------
BACKGROUND

microEWT is a graphical user interface library  written in Java for 
mobile devices running Java 2 Micro Edition (J2ME). It is based on the 
LGPL open source project J2ME-Lib, a J2ME tool library. For further 
information about these libraries please check the documentation on 
our website (http://www.esoco.net). The source code and other downloads
are available from the project pages at SourceForge.

-----------------------------------------------------------------------
LICENSE INFORMATION

microEWT is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

microEWT is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along
with microEWT; if not, write to the Free Software Foundation, Inc., 
51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
    
-----------------------------------------------------------------------
CHANGES

Version 0.92 - 30.07.2007
New Component: ComboBox
Several bug fixes and optimizations 

Version 0.9 - 25.06.2007
First public release
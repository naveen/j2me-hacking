package thinlet;

public class Break extends Widget {
	
	public Break() {
	}
}

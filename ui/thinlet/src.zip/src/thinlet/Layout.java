package thinlet;

public class Layout {
	
	public Widget.Metrics getPreferredSize(Widget target, int preferredWidth) {
		return null;
	}
	
	public void doLayout(Widget target) {
	}
}

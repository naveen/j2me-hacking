package thinlet.demo;

import java.awt.*;
import java.util.*;
import thinlet.*;

public class CheckWidget extends Widget {
	
	public CheckWidget() {
		//startTimer(0, 500, null);
	}
	
	protected boolean timerEvent(Object parameter) {
		repaint(); return true;
	}
	
	public Metrics getPreferredSize(int preferredWidth) {
		return new Metrics(122, 42);
	}
	
	protected void paint(Graphics g) {
		g.setColor(new Color(0xe6edf7)); // 0.5980392f, 0.06882591f, 0.96862745f
//		float[] hsbvals = new float[3]; Color.RGBtoHSB(0xe6, 0xed, 0xf7, hsbvals);
//		for (int i = 0; i < hsbvals.length; i++) System.out.println(hsbvals[i]);
		g.fillRect(0, 0, getWidth(), getHeight());
		Random random = new Random();
		for (int x = 0; x < 12; x++) {
			for (int y = 0; y < 4; y++) {
				g.setColor(Color.getHSBColor(0.5980392f, 0.06882591f + x / 18f * random.nextFloat(), 0.96862745f));
				g.fillRect(2 + x * 10, 2 + y * 10, 8, 8);
			}
		}
	}
}

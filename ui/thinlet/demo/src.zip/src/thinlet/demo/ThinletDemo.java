package thinlet.demo;

//:PP import thinlet.Button;
//:PP import java.awt.*;
//:PP import java.awt.event.*;
import javax.swing.*; //:J2
import thinlet.*;

public class ThinletDemo {
	
	private ThinletDemo() {
		Pane content = new Pane();
		try {
			new Parser(content, "thinlet/demo/thinletdemo.xml");
		} catch (Exception exc) { exc.printStackTrace(); }
		content.add(new EventTestWidget());
		content.add(new CheckWidget());
		Button button = new Button("Button");
//		button.setPainter(new Painter() {
//			public void paint(Graphics g, Widget target) {
//				g.setColor(Color.blue);
//				g.drawRect(0, 0, 10, 10);
//			}
//		});
		button.addActionListener(new Listener(this, "buttonPressed"));
		button.addActionListener(new Listener(this, "buttonPressed2"));
		content.add(button);
		content.add(new HelpButton());
		content.add(new DateField());
		
		JFrame frame = new JFrame(); //:J2
		//:PPFrame frame = new Frame();
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //:J2
		/*:PP frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) { System.exit(0); }
		});*/
		frame.setContentPane((JComponent) content.getComponent()); //:J2
		//:PP frame.add(content.getComponent(), BorderLayout.CENTER);
		frame.pack();
		frame.setBounds(320, 160, 744, 480);
		frame.setVisible(true);
	}

	public void buttonPressed() { System.out.println("> button pressed"); }
	public void buttonPressed2() { System.out.println("> button pressed 2"); throw new IllegalArgumentException(); }

	public static void main(String[] args) {
		new ThinletDemo();
	}
}

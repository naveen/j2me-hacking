package thinlet.demo;

import java.awt.*;
import java.awt.event.*;
import thinlet.*;

public class HelpButton extends Widget {

	protected void process(AWTEvent e) {
		if (e.getID() == MouseEvent.MOUSE_PRESSED) {
			new HelpText("The content of the popup help.").popup(this, 0, getHeight());
		}
	}
	
	public Metrics getPreferredSize(int preferredWidth) {
		return new Metrics(16, 16);
	}
	
	protected void paint(Graphics g) {
		g.setColor(new Color(0x6699cc));
		g.fillOval(0, 0, 16, 16);
		g.setColor(new Color(0xacc7e3));
		g.drawOval(1, 1, 13, 13);
		g.setColor(Color.white);
		g.setFont(new Font("SansSerif", Font.BOLD, 10));
		FontMetrics fm = g.getFontMetrics();
		g.drawString("?", (16 - fm.charWidth('?') + 1) / 2,
			(16 + fm.getAscent() - fm.getDescent() + 1) / 2);
	}
	
	private static class HelpText extends Widget {
		
		private HelpText(String text) {
			add(new Text(text));
			setLayout(new InlineLayout(4, 4, 4, 4));
		}
		
		protected void paint(Graphics g) {
			g.setColor(Color.lightGray);
			g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
			g.setColor(new Color(0xffff99));
			g.fillRect(1, 1, getWidth() - 2, getHeight() - 2);
			g.setColor(Color.darkGray);
			super.paint(g);
		}
	}
}
